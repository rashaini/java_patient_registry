/**
 * @author rim_ahsaini
 * JFrame class used to add patients 
 * Defines objects of type patients used to add all patients' attributes
 */

package guiPatient;

import javax.swing.JPanel;


import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.NumberFormatter;
import patientPack.Database;
import patientPack.Patient;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.EventQueue;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import javax.swing.JEditorPane;



public class AddPatientFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	public Patient pattoAdd;
	private JPanel contentPane;
	private JTextField fNfield;
	private JTextField lNfield;
	private JButton dobbutton;
	private ObservingTextField dobfield;
	private JTextField addressfield;
	private JFormattedTextField emgNbfield;
	private JTextField medConfield;
	private JTextField comField;
	private JLabel profilePiclabel;
	private String path;
	private String scan_path1;
	private String scan_path2;
	
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddPatientFrame frame = new AddPatientFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddPatientFrame() {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 664, 561);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		profilePiclabel = new JLabel();
		profilePiclabel.setHorizontalAlignment(SwingConstants.CENTER);
		profilePiclabel.setBounds(410, 24, 218, 137);
		contentPane.add(profilePiclabel);
		
		JButton btnAddProfilePic = new JButton("Add Profile Picture");
		btnAddProfilePic.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel panel = new JPanel();
				JFileChooser fc = new JFileChooser();
				FileFilter filter = new FileNameExtensionFilter("JPEG file", "jpg", "jpeg", "png");
	            fc.setFileFilter(filter);
				int view = fc.showOpenDialog(panel);
				if (view == JFileChooser.APPROVE_OPTION) { 
				path = (fc.getSelectedFile().getPath());
				ImageIcon addedpic = new ImageIcon(path);
				profilePiclabel.setIcon(addedpic);
				profilePiclabel.setText(null);
				}
				
			}
		});
		btnAddProfilePic.setBounds(461, 177, 145, 29);
		contentPane.add(btnAddProfilePic);
		btnAddProfilePic.setToolTipText("Add patient's profile picture here");
		
		JLabel lNlabel = new JLabel("Last Name");
		lNlabel.setBounds(20, 56, 71, 14);
		contentPane.add(lNlabel);
		
		JLabel fNlabel = new JLabel("First Name");
		fNlabel.setBounds(20, 24, 71, 14);
		contentPane.add(fNlabel);
		
		JLabel doblabel = new JLabel("Date of Birth");
		doblabel.setBounds(20, 89, 167, 14);
		contentPane.add(doblabel);
		
		JLabel addresslabel = new JLabel("Address");
		addresslabel.setBounds(20, 127, 71, 14);
		contentPane.add(addresslabel);
		
		JLabel emgNblabel = new JLabel("Emergency Number");
		emgNblabel.setBounds(20, 160, 145, 16);
		contentPane.add(emgNblabel);
		
		JLabel medConlabel = new JLabel("Medical Condition");
		medConlabel.setBounds(20, 194, 130, 16);
		contentPane.add(medConlabel);
		
		JLabel onlineLabel = new JLabel("Online Link");
		onlineLabel.setBounds(20, 265, 96, 16);
		contentPane.add(onlineLabel);
		
		JLabel comlabel = new JLabel("Comments");
		comlabel.setBounds(20, 232, 71, 16);
		contentPane.add(comlabel);
		
		
		fNfield = new JTextField();
		fNfield.setBounds(223, 18, 130, 26);
		contentPane.add(fNfield);
		fNfield.setColumns(10);
		fNfield.setToolTipText("Enter patient's firstname here");
		
		lNfield = new JTextField();
		lNfield.setColumns(10);
		lNfield.setBounds(223, 50, 130, 26);
		contentPane.add(lNfield);
		lNfield.setToolTipText("Enter patient's lastname here");
		
		dobfield = new ObservingTextField();
		dobfield.setBounds(223, 83, 101, 26);
		contentPane.add(dobfield);
		dobfield.setColumns(10);
		
		/**
		 * DatePicker uses two other classes created and an external library 
		 * DatePicker designs and implements the date picker 
		 * ObservingTextField sets a new textfield object to display the date picker 
		 * This was used with help of youtube tutorial https://www.youtube.com/watch?v=zXOqELX44II
		 */
		
		dobbutton = new JButton("Choose");
		dobbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = null;
				final Locale locale = getLocale(s);
				DatePicker dp = new DatePicker(dobfield, locale);
				Date selectedDate = dp.parseDate(dobfield.getText());
				dp.setSelectedDate(selectedDate);
				dp.start(dobfield);
			}
			
			private Locale getLocale(String loc) {
				if (loc != null && loc.length() > 0)
					return new Locale(loc);
				else 
					return Locale.UK;
			}
		});
		dobbutton.setBounds(326, 83, 72, 29);
		contentPane.add(dobbutton);
		dobbutton.setToolTipText("Add patient's date of birth here");
		
		addressfield = new JTextField();
		addressfield.setColumns(10);
		addressfield.setBounds(223, 121, 130, 26);
		contentPane.add(addressfield);
		addressfield.setToolTipText("Enter patient's address here");
		
		NumberFormat longFormat = NumberFormat.getIntegerInstance();
		NumberFormatter numberFormatter = new NumberFormatter(longFormat);
		numberFormatter.setValueClass(Integer.class); 
		numberFormatter.setAllowsInvalid(false);
	
		emgNbfield = new JFormattedTextField(numberFormatter);
		emgNbfield.setColumns(10);
		emgNbfield.setBounds(223, 155, 130, 26);
		contentPane.add(emgNbfield);
		emgNbfield.setToolTipText("Accepts numbers only");
		
		medConfield = new JTextField();
		medConfield.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		medConfield.setColumns(10);
		medConfield.setBounds(223, 189, 130, 26);
		contentPane.add(medConfield);
		medConfield.setToolTipText("Enter patient's medical condition here");
		
		JEditorPane onlineEditorPane = new JEditorPane();
		onlineEditorPane.setBounds(223, 265, 130, 16);
		contentPane.add(onlineEditorPane);
		onlineEditorPane.setToolTipText("Enter link to patient's medical condition here");
		
		comField = new JTextField();
		comField.setColumns(10);
		comField.setBounds(223, 227, 130, 26);
		contentPane.add(comField);
		comField.setToolTipText("Enter comments about patient here");
		
		JLabel Scan1Label = new JLabel("Scan");
		Scan1Label.setHorizontalAlignment(SwingConstants.CENTER);
		Scan1Label.setBounds(193, 308, 130, 109);
		contentPane.add(Scan1Label);
		
		JLabel Scan2Label = new JLabel("Scan");
		Scan2Label.setHorizontalAlignment(SwingConstants.CENTER);
		Scan2Label.setBounds(373, 308, 130, 109);
		contentPane.add(Scan2Label);
		
		/**
		 * Button upload scans uses file chooser method with filter 
		 * One button is used to display image icons in two jlabels, using a method from left to right 
		 */
		
		JButton btnUploadScans = new JButton("Upload Scans");
		btnUploadScans.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel panel = new JPanel();
				JFileChooser fc = new JFileChooser();
				FileFilter filter = new FileNameExtensionFilter("JPEG file", "jpg", "jpeg", "png");
	            fc.setFileFilter(filter);
				int view = fc.showOpenDialog(panel);
				if (view == JFileChooser.APPROVE_OPTION) { 
				if (Scan1Label.getIcon() == null) {
				    scan_path1 = (fc.getSelectedFile().getPath());
					ImageIcon addedpic1 = new ImageIcon(scan_path1);
				    Scan1Label.setIcon(addedpic1);
				    Scan1Label.setText(null);}
				else if (Scan1Label.getIcon() != null) {
				    scan_path2 = (fc.getSelectedFile().getPath());
					ImageIcon addedpic2 = new ImageIcon(scan_path2);
				    Scan2Label.setIcon(addedpic2); 
				    Scan2Label.setText(null);}
				
				}
			}
		});
		btnUploadScans.setBounds(17, 303, 117, 29);
		contentPane.add(btnUploadScans);
		btnUploadScans.setToolTipText("Up to 2 scans can be uploaded from left to right");
		
		JLabel apptLabel = new JLabel("Appointments");
		apptLabel.setHorizontalAlignment(SwingConstants.CENTER);
		apptLabel.setBounds(20, 451, 96, 16);
		contentPane.add(apptLabel);
		
		ObservingTextField apptDay = new ObservingTextField();
		apptDay.setColumns(10);
		apptDay.setBounds(141, 441, 101, 26);
		contentPane.add(apptDay);
		
		JButton btnChooseDay = new JButton("Choose Day");
		btnChooseDay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = null;
				final Locale locale = getLocale(s);
				DatePicker dp = new DatePicker(apptDay, locale);
				Date selectedDate = dp.parseDate(apptDay.getText());
				dp.setSelectedDate(selectedDate);
				dp.start(apptDay);
			}
			
			private Locale getLocale(String loc) {
				if (loc != null && loc.length() > 0)
					return new Locale(loc);
				else 
					return Locale.UK;
			}
		});
		btnChooseDay.setBounds(239, 441, 114, 29);
		contentPane.add(btnChooseDay);
		btnChooseDay.setToolTipText("Change appointment day here");
		
		JTextField apptHour = new JTextField();
		apptHour.setColumns(10);
		apptHour.setBounds(249, 480, 101, 26);
		contentPane.add(apptHour);
		apptHour.setToolTipText("Change appointment time here");
		
		/**
		 * Button 'Add' only adds a new patient to the list if almost all fields are completed, for better data availability when the practitioner queries the system afterwards 
		 * Gets back to the Patient Panel if button 'Cancel' is hit 
		 */
	
		JButton btnAddPatient = new JButton("Add Patient ");
		btnAddPatient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (profilePiclabel.getIcon() == null || fNfield.getText() == null || lNfield.getText() == null || dobfield.getText() == null || addressfield.getText() == null
						|| emgNbfield.getText() == null || medConfield.getText() == null || comField.getText() == null ||apptDay.getText() == null || apptHour.getText() == null) {
					
					JOptionPane.showMessageDialog(null, "Please complete all fields (exception made for scans)!");
				} else {
					
				pattoAdd = new Patient(path, lNfield.getText(), fNfield.getText(), dobfield.getText() ,addressfield.getText(), 
						emgNbfield.getText(), medConfield.getText(), onlineEditorPane.getText(), comField.getText(), scan_path1, 
						scan_path2, apptDay.getText(), apptHour.getText());
				
				Database.PatientsList.add(pattoAdd);
				
				AddPatientFrame.this.dispose();
				}
			}
		});
		btnAddPatient.setBounds(450, 446, 167, 29);
		contentPane.add(btnAddPatient);
		btnAddPatient.setToolTipText("Add patient to database here");
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddPatientFrame.this.dispose();
			}
		});
		btnCancel.setBounds(497, 480, 86, 29);
		contentPane.add(btnCancel);
		btnCancel.setToolTipText("Cancel adding here");
		
		JLabel lblNewLabel = new JLabel("Choose Time");
		lblNewLabel.setBounds(151, 485, 86, 16);
		contentPane.add(lblNewLabel);
		
	}
}
