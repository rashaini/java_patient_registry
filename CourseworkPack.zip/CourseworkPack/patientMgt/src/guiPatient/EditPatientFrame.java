/**
 * @author rim_ahsaini
 * JFrame class used to edit patients' information 
 * Unlike the Patient Panel class, jcomponents of this class are editable and allow the user to change patients' data
 * When the frame opens, it is loaded with data saved from arraylist in Database class
 */

package guiPatient;

import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.text.NumberFormatter;
import patientPack.Database;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFormattedTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JEditorPane;

public class EditPatientFrame extends JFrame {

	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField fNfield;
	private JTextField lNfield;
	private ObservingTextField dobfield;
	private JTextField addressfield;
	private JFormattedTextField emgNbfield;
	private JTextField medConfield;
	private JTextField comfield;
	private JLabel profilePiclabel;
	private String path;
	private String scan_path1;
	private String scan_path2;
	private ObservingTextField apptDay;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EditPatientFrame frame = new EditPatientFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EditPatientFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 574);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		/**
		 * Load profile picture and display it as buffered image
		 */
		
		profilePiclabel = new JLabel("pic");
		profilePiclabel.setHorizontalAlignment(SwingConstants.CENTER);
		profilePiclabel.setBounds(459, 30, 130, 132);
		contentPane.add(profilePiclabel);
		profilePiclabel.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getProfilePic());
		if (Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getProfilePic() != null) {
			ImageIcon icon_profile = null;
			try {
				Image image_profile = ImageIO.read(new File(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getProfilePic()));
				BufferedImage sized_image = new BufferedImage(profilePiclabel.getWidth(),profilePiclabel.getHeight(),BufferedImage.TYPE_INT_RGB);
				Graphics g_profile = sized_image.createGraphics();
				g_profile.drawImage(image_profile, 0, 0, profilePiclabel.getWidth(), profilePiclabel.getHeight(),null);
				g_profile.dispose();
				icon_profile = new ImageIcon(sized_image);
			} catch (IOException e) {
				e.printStackTrace();
			} 
			profilePiclabel.setIcon(icon_profile);
		} else if (Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getProfilePic() == null) {
			profilePiclabel.setText("No Profile Picture");
		}
		
		/**
		 * Button change profile picture
		 * Uses file chooser together with filter to only choose from pictures with extensions below 
		 */
		
		JButton btnChangePhot = new JButton("Change Photo");
		btnChangePhot.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel panel = new JPanel();
				JFileChooser fc = new JFileChooser();
				FileFilter filter = new FileNameExtensionFilter("JPEG file", "jpg", "jpeg", "png");
	            fc.setFileFilter(filter);
				int view = fc.showOpenDialog(panel);
				if (view == JFileChooser.APPROVE_OPTION) { 
				path = (fc.getSelectedFile().getPath());
				ImageIcon addedpic = new ImageIcon(path);
				profilePiclabel.setIcon(addedpic);
				profilePiclabel.setText(null);
				}
			}
		});
		btnChangePhot.setBounds(471, 177, 117, 29);
		contentPane.add(btnChangePhot);
		btnChangePhot.setToolTipText("Change patient's profile picture here");
		
		
		JLabel lNlabel = new JLabel("Last Name");
		lNlabel.setBounds(20, 56, 71, 14);
		contentPane.add(lNlabel);
		
		JLabel fNlabel = new JLabel("First Name");
		fNlabel.setBounds(20, 24, 71, 14);
		contentPane.add(fNlabel);
		
		JLabel doblabel = new JLabel("Date of Birth");
		doblabel.setBounds(20, 89, 167, 14);
		contentPane.add(doblabel);
		
		JLabel addresslabel = new JLabel("Address");
		addresslabel.setBounds(20, 127, 71, 14);
		contentPane.add(addresslabel);
		
		JLabel emgNblabel = new JLabel("Emergency Number");
		emgNblabel.setBounds(20, 160, 145, 16);
		contentPane.add(emgNblabel);
		
		JLabel medConlabel = new JLabel("Medical Condition");
		medConlabel.setBounds(20, 271, 130, 16);
		contentPane.add(medConlabel);
		
		JLabel onlineLabel = new JLabel("Online Link");
		onlineLabel.setBounds(20, 194, 101, 16);
		contentPane.add(onlineLabel);
		
		JLabel comlabel = new JLabel("Comments");
		comlabel.setBounds(20, 232, 71, 16);
		contentPane.add(comlabel);
		
		fNfield = new JTextField();
		fNfield.setBounds(223, 18, 130, 26);
		contentPane.add(fNfield);
		fNfield.setColumns(10);
		fNfield.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getFirstName());
		fNfield.setToolTipText("Edit patient's firstname here");
		
		lNfield = new JTextField();
		lNfield.setColumns(10);
		lNfield.setBounds(223, 50, 130, 26);
		contentPane.add(lNfield);
		lNfield.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getLastName());
		lNfield.setToolTipText("Edit patient's lastname here");
		
		dobfield = new ObservingTextField();
		dobfield.setBounds(223, 83, 101, 26);
		contentPane.add(dobfield);
		dobfield.setColumns(10);
		dobfield.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getDob());
		
		/**
		 * Button for choosing date of birth 
		 * DatePicker as used in Add Patient Frame class 
		 */
		JButton dobbutton = new JButton("Change");
		dobbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = null;
				final Locale locale = getLocale(s);
				DatePicker dp = new DatePicker(dobfield, locale);
				Date selectedDate = dp.parseDate(dobfield.getText());
				dp.setSelectedDate(selectedDate);
				dp.start(dobfield);
			}
			
			private Locale getLocale(String loc) {
				if (loc != null && loc.length() > 0)
					return new Locale(loc);
				else 
					return Locale.UK;
			}
		});
		dobbutton.setBounds(326, 83, 72, 29);
		contentPane.add(dobbutton);
		dobbutton.setToolTipText("Edit patient's date of birth here");
		
		addressfield = new JTextField();
		addressfield.setColumns(10);
		addressfield.setBounds(223, 121, 130, 26);
		contentPane.add(addressfield);
		addressfield.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getAddress());
		addressfield.setToolTipText("Edit patient's address here");
		
		/**
		 * Emergency number field only accepts integers 
		 */
		
		NumberFormat longFormat = NumberFormat.getIntegerInstance();
		NumberFormatter numberFormatter = new NumberFormatter(longFormat);
		numberFormatter.setValueClass(Integer.class); 
		numberFormatter.setAllowsInvalid(false);
	
		emgNbfield = new JFormattedTextField(numberFormatter);
		emgNbfield.setColumns(10);
		emgNbfield.setBounds(223, 155, 130, 26);
		contentPane.add(emgNbfield);
		emgNbfield.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getEmgNb());
		emgNbfield.setToolTipText("Accepts numbers only");
		
		medConfield = new JTextField();
		medConfield.setColumns(10);
		medConfield.setBounds(223, 189, 130, 26);
		contentPane.add(medConfield);
		medConfield.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getMedCon());
		medConfield.setToolTipText("Edit patient's medical condition here");
		
		JEditorPane onlineEditorPane = new JEditorPane();
		onlineEditorPane.setBounds(223, 271, 145, 16);
		contentPane.add(onlineEditorPane);
		onlineEditorPane.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getOnlineDoc());
		onlineEditorPane.setToolTipText("Edit link to patient's medical condition here");
		
		comfield = new JTextField();
		comfield.setColumns(10);
		comfield.setBounds(223, 227, 130, 26);
		contentPane.add(comfield);
		comfield.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getComment());
		comfield.setToolTipText("Edit comments about patient here");
		
		/**
		 * Load scans 
		 */
		
		JLabel Scan1Label = new JLabel("Scan");
		Scan1Label.setHorizontalAlignment(SwingConstants.CENTER);
		Scan1Label.setBounds(166, 321, 130, 109);
		contentPane.add(Scan1Label);
		Scan1Label.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan1());
		if (Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan1() != null) {
			ImageIcon icon_scan1 = null;
			try {
				Image image_scan1 = ImageIO.read(new File(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan1()));
				BufferedImage sized_image = new BufferedImage(Scan1Label.getWidth(),Scan1Label.getHeight(),BufferedImage.TYPE_INT_RGB);
				Graphics g_scan1 = sized_image.createGraphics();
				g_scan1.drawImage(image_scan1, 0, 0, Scan1Label.getWidth(), Scan1Label.getHeight(),null);
				g_scan1.dispose();
				icon_scan1 = new ImageIcon(sized_image);
			} catch (IOException e) {
				e.printStackTrace();
			} 
			Scan1Label.setIcon(icon_scan1);
		} else if (Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan1() == null) {
			Scan1Label.setText("No Scan Available");
		}
		
		
		JLabel Scan2Label = new JLabel("Scan");
		Scan2Label.setHorizontalAlignment(SwingConstants.CENTER);
		Scan2Label.setBounds(492, 321, 130, 109);
		contentPane.add(Scan2Label);
		Scan2Label.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan2());
		if (Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan2() != null) {
			ImageIcon icon_scan2 = null;
			try {
				Image image_scan2 = ImageIO.read(new File(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan2()));
				BufferedImage sized_image = new BufferedImage(Scan2Label.getWidth(),Scan2Label.getHeight(),BufferedImage.TYPE_INT_RGB);
				Graphics g_scan2 = sized_image.createGraphics();
				g_scan2.drawImage(image_scan2, 0, 0, Scan2Label.getWidth(), Scan2Label.getHeight(),null);
				g_scan2.dispose();
				icon_scan2 = new ImageIcon(sized_image);
			} catch (IOException e) {
				e.printStackTrace();
			} 
			Scan2Label.setIcon(icon_scan2);
		} else if (Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan2() == null) {
			Scan2Label.setText("");
		}
		
		/**
		 * Buttons for changing scans or removing them 
		 */
		
		JButton btnAddScans1 = new JButton("Add Scan 1");
		btnAddScans1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel panel = new JPanel();
				JFileChooser fc = new JFileChooser();
				FileFilter filter = new FileNameExtensionFilter("JPEG file", "jpg", "jpeg", "png");
	            fc.setFileFilter(filter);
				int view = fc.showOpenDialog(panel);
				if (view == JFileChooser.APPROVE_OPTION) { 
				    scan_path1 = (fc.getSelectedFile().getPath());
					ImageIcon addedpic1 = new ImageIcon(scan_path1);
				    Scan1Label.setIcon(addedpic1);
				    Scan1Label.setText(null);
				}
			}
		});
		btnAddScans1.setBounds(20, 342, 124, 29);
		contentPane.add(btnAddScans1);
		btnAddScans1.setToolTipText("Up to 2 scans can be uploaded from left to right");
		
		JButton btnAddScans2 = new JButton("Add Scan 2");
		btnAddScans2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JPanel panel = new JPanel();
				JFileChooser fc = new JFileChooser();
				FileFilter filter = new FileNameExtensionFilter("JPEG file", "jpg", "jpeg", "png");
	            fc.setFileFilter(filter);
				int view = fc.showOpenDialog(panel);
				if (view == JFileChooser.APPROVE_OPTION) { 
				    scan_path2 = (fc.getSelectedFile().getPath());
					ImageIcon addedpic2 = new ImageIcon(scan_path2);
				    Scan2Label.setIcon(addedpic2); 
				    Scan2Label.setText(null);
				}
			}
		});
		btnAddScans2.setToolTipText("Up to 2 scans can be uploaded from left to right");
		btnAddScans2.setBounds(326, 342, 124, 29);
		contentPane.add(btnAddScans2);
		
		JButton btnRemoveScan1 = new JButton("Remove Scan 1");
		btnRemoveScan1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Scan1Label.setIcon(null);
				Scan1Label.setText("No scan available");
			}
		});
		btnRemoveScan1.setBounds(20, 383, 130, 29);
		contentPane.add(btnRemoveScan1);
		
		JButton btnRemoveScan2 = new JButton("Remove Scan 2");
		btnRemoveScan2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Scan2Label.setIcon(null); 
				Scan2Label.setText("No scan available");
			}
		});
		btnRemoveScan2.setBounds(326, 383, 130, 29);
		contentPane.add(btnRemoveScan2);
		
		JLabel apptLabel = new JLabel("Appointments");
		apptLabel.setHorizontalAlignment(SwingConstants.CENTER);
		apptLabel.setBounds(69, 453, 96, 16);
		contentPane.add(apptLabel);
		
		apptDay = new ObservingTextField();
		apptDay.setColumns(10);
		apptDay.setBounds(69, 481, 101, 26);
		contentPane.add(apptDay);
		apptDay.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getApptDay());
		
		JButton btnChangeDay = new JButton("Change Day");
		btnChangeDay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String s = null;
				final Locale locale = getLocale(s);
				DatePicker dp = new DatePicker(apptDay, locale);
				Date selectedDate = dp.parseDate(apptDay.getText());
				dp.setSelectedDate(selectedDate);
				dp.start(apptDay);
			}
			
			private Locale getLocale(String loc) {
				if (loc != null && loc.length() > 0)
					return new Locale(loc);
				else 
					return Locale.UK;
			}
		});
		btnChangeDay.setBounds(182, 481, 114, 29);
		contentPane.add(btnChangeDay);
		
		JLabel lblNewLabel = new JLabel("Change Time");
		lblNewLabel.setBounds(91, 522, 82, 16);
		contentPane.add(lblNewLabel);
		
		JTextField apptHour = new JTextField();
		apptHour.setColumns(10);
		apptHour.setBounds(192, 517, 101, 26);
		contentPane.add(apptHour);
		apptHour.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getApptHour());
		
	
		JButton btnSaveChanges = new JButton("Save Changes");
		btnSaveChanges.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setProfilePic(profilePiclabel.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setFirstName(fNfield.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setLastName(lNfield.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setAddress(addressfield.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setDob(dobfield.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setEmgNb(emgNbfield.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setMedCon(medConfield.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setOnlineDoc(onlineEditorPane.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setComment(comfield.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setScan1(Scan1Label.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setScan2(Scan2Label.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setApptDay(apptDay.getText());
				Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).setApptHour(apptHour.getText());
				
				EditPatientFrame.this.dispose();
			}
		});
		btnSaveChanges.setBounds(561, 517, 117, 29);
		contentPane.add(btnSaveChanges);
		btnSaveChanges.setToolTipText("Save changes to patient's record here");
		
		JButton btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EditPatientFrame.this.dispose();
			}
		});
		btnCancel.setBounds(432, 517, 117, 29);
		contentPane.add(btnCancel);
		btnCancel.setToolTipText("Cancel changes here");
		

	}
}
