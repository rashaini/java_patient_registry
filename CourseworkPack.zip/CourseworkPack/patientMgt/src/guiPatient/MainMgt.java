/**
 * @author rim_ahsaini
 * Jframe class that contains main for launching PatientPanel jpanel class 
 */

package guiPatient;

import java.awt.EventQueue;
import javax.swing.JFrame;

import patientPack.Database;
import patientPack.Patient;


public class MainMgt {

	private JFrame frame;
	private static int count;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMgt window = new MainMgt();
					window.frame.getContentPane().add(new PatientPanel());
					window.frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainMgt() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 803, 498);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void setVisible(boolean b) {
		
		MainMgt window = new MainMgt();
		window.frame.getContentPane().add(new PatientPanel());
		window.frame.setVisible(true);
	}

	

}
