/**
 * @author rim_ahsaini + 'The Howto Tutorial' on https://www.youtube.com/watch?v=zXOqELX44II 
 * Creates observing textfield object display result of datepicker 
 */

package guiPatient;

import java.util.Calendar;

import java.util.Observable;
import java.util.Observer;

import javax.swing.JTextField;

public class ObservingTextField extends JTextField implements Observer {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void update(Observable ob, Object obj) {
        Calendar calendar = (Calendar) obj;
        DatePicker dp = (DatePicker) ob;
        setText(dp.formatDate(calendar));
    }
}
