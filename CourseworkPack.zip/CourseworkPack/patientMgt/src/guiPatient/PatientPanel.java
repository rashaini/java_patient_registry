/**
 * @author rim_ahsaini
 * This jpanel class is the main patient panel in which the information of the patients gets displayed 
 * It also contains different buttons with different features 
 * Add and Edit buttons take the user to different frames 
 * All the other actions are dealt with in this same jpanel
 */


package guiPatient;

import javax.swing.JPanel;

import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Desktop;

import javax.swing.border.LineBorder;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import org.jdatepicker.DateModel;
import org.jdatepicker.impl.JDatePanelImpl;
import org.jdatepicker.impl.JDatePickerImpl;
import org.jdatepicker.impl.UtilDateModel;

import patientPack.Database;
import patientPack.Patient;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.List;

import javax.imageio.ImageIO;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Properties;

import javax.swing.JLabel;
import java.awt.TextField;
import java.awt.Button;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;

public class PatientPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	
	private JTextField fNameField;
	private JTextField lNameField;
	private JTextField addressField;
	private JTextField dobField;
	private JTextField emgNbField;
	private JTextField medConField;
	private JTextField comField;
	private JLabel profilePicLabel;
	private JEditorPane onlineEditorPane;
	private ObservingTextField dayfield;
	
	static List patientsListGui;
	private JTextField searchField;
	
	/**
	 * Method that fills GUI Class list (= patientsListGui) with elements of Database Class list (= PatientsList)
	 */

		public void fill_list(List lst) {
			int num_elements_patientslist = 0;
			if (lst.getItemCount() != 0 )
				lst.removeAll();
				
			for(num_elements_patientslist=0; num_elements_patientslist < Database.PatientsList.size();num_elements_patientslist++)
			{
				lst.add(Database.PatientsList.get(num_elements_patientslist).getLastName() + ", " + 
			Database.PatientsList.get(num_elements_patientslist).getFirstName()); // + ", " +  Database.PatientsList.get(num_elements_patientslist).getID());
			}
		}
	
	/**
	 * Create the panel.
	 */
	@SuppressWarnings("deprecation")
	public PatientPanel() {
			
		setBackground(Color.WHITE);
		
		//Initialize patientsListGui 
		patientsListGui = new List();
		patientsListGui.setMultipleSelections(false);
		patientsListGui.setBounds(10, 144, 178, 379);
		patientsListGui.setForeground(Color.BLACK);
		patientsListGui.setBackground(Color.WHITE);
				
		//Pass patientsListGui as argument to fill_list method
		fill_list(patientsListGui);
					
		//Add patientsListGui to the JPanel
		setLayout(null);
		add(patientsListGui);
		
		/**
		 * Populate the panel with JComponents
		 */
			
			JLabel lpLabel = new JLabel("List of Patients");
			lpLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lpLabel.setBounds(38, 124, 112, 14);
			add(lpLabel);
			
			JLabel fNameLabel = new JLabel("First Name");
			fNameLabel.setBounds(206, 12, 97, 14);
			add(fNameLabel);
			
			JLabel lNameLabel = new JLabel("Last Name");
			lNameLabel.setBounds(206, 49, 67, 14);
			add(lNameLabel);
			
			JLabel addressLabel = new JLabel("Address");
			addressLabel.setBounds(206, 84, 67, 14);
			add(addressLabel);
			
			JLabel dobLabel = new JLabel("Date of Birth");
			dobLabel.setBounds(206, 119, 97, 14);
			add(dobLabel);
			
			JLabel emgNbLabel = new JLabel("Emergency Number");
			emgNbLabel.setBounds(206, 156, 129, 16);
			add(emgNbLabel);
			
			JLabel medConLabel = new JLabel("Medical Condition");
			medConLabel.setBounds(206, 194, 129, 16);
			add(medConLabel);
			
			JLabel onlineLabel = new JLabel("Online Link");
			onlineLabel.setBounds(206, 277, 97, 16);
			add(onlineLabel);
			
			JLabel comLabel = new JLabel("Comments");
			comLabel.setBounds(206, 234, 79, 16);
			add(comLabel);
			
			profilePicLabel = new JLabel("Profile Picture");
			profilePicLabel.setHorizontalAlignment(SwingConstants.CENTER);
			profilePicLabel.setBounds(593, 24, 117, 96);
			add(profilePicLabel);
			profilePicLabel.setToolTipText("After, adding your patients, you will be able to see each one's profile picture here");
			
			
			fNameField = new JTextField();
			fNameField.setBounds(347, 6, 130, 26);
			add(fNameField);
			fNameField.setColumns(10);
			fNameField.setEditable(false);
			
			lNameField = new JTextField();
			lNameField.setBounds(347, 43, 130, 26);
			add(lNameField);
			lNameField.setColumns(10);
			lNameField.setEditable(false);
			
			addressField = new JTextField();
			addressField.setBounds(347, 78, 130, 26);
			add(addressField);
			addressField.setColumns(10);
			addressField.setEditable(false);
			
			dobField = new JTextField();
			dobField.setBounds(347, 113, 130, 26);
			add(dobField);
			dobField.setColumns(10);
			dobField.setEditable(false);
			
			//only allow integers input http://stackoverflow.com/questions/11093326/restricting-jtextfield-input-to-integers
			emgNbField = new JTextField();
			emgNbField.setBounds(347, 151, 130, 26);
			add(emgNbField);
			emgNbField.setColumns(10);
			emgNbField .setEditable(false);
			
			medConField = new JTextField();
			medConField.setBounds(347, 189, 130, 26);
			add(medConField);
			medConField.setColumns(10);
			medConField.setEditable(false);
			
			onlineEditorPane = new JEditorPane();
			onlineEditorPane.setBounds(347, 277, 144, 16);
			add(onlineEditorPane);
			
			comField = new JTextField();
			comField.setBounds(347, 229, 130, 26);
			add(comField);
			comField.setColumns(10);
			comField.setEditable(false);
			
			JLabel scansLabel = new JLabel("Scans");
			scansLabel.setBounds(224, 343, 61, 16);
			add(scansLabel);
			
			JLabel Scan1Label = new JLabel("");
			Scan1Label.setHorizontalAlignment(SwingConstants.CENTER);
			Scan1Label.setBounds(357, 318, 130, 109);
			add(Scan1Label);
			
			JLabel Scan2Label = new JLabel("");
			Scan2Label.setHorizontalAlignment(SwingConstants.CENTER);
			Scan2Label.setBounds(562, 318, 130, 109);
			add(Scan2Label);
			
			JLabel apptLabel = new JLabel("Appointments");
			apptLabel.setHorizontalAlignment(SwingConstants.CENTER);
			apptLabel.setBounds(279, 464, 97, 16);
			add(apptLabel);
			
			JLabel dayLabel = new JLabel("Day");
			dayLabel.setHorizontalAlignment(SwingConstants.CENTER);
			dayLabel.setBounds(254, 502, 49, 16);
			add(dayLabel);
			
			JLabel hourLabel = new JLabel("Hour");
			hourLabel.setHorizontalAlignment(SwingConstants.CENTER);
			hourLabel.setBounds(254, 540, 49, 16);
			add(hourLabel);
			
			dayfield = new ObservingTextField();
			dayfield.setColumns(10);
			dayfield.setBounds(330, 497, 101, 26);
			add(dayfield);
			dayfield.setEditable(false);
			
			JTextField hourfield = new JTextField();
			hourfield.setColumns(10);
			hourfield.setBounds(330, 535, 101, 26);
			add(hourfield);
			hourfield.setEditable(false);
			
			
		/**
		  * Add button
		  * Displays the add patient frame, allowing users to add patients and their attributes
		  * See more detailed comments provided in add patient frame class 
		  */
			
			JButton btnAdd = new JButton("Add New Patient");
			btnAdd.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					AddPatientFrame Addframe = new AddPatientFrame();
					Addframe.setVisible(true);
				}
			});
			btnAdd.setBounds(569, 451, 196, 29);
			add(btnAdd);
			btnAdd.setToolTipText("Click here to add patients");
			
			
		/**
		 * Edit selected patient button
		 * Displays the edit patient frame with editable labels and textfields 
		 * See more detailed comments provided in edit patient frame class 
		 */
			JButton btnEditSelectPat = new JButton("Edit Selected Patient");
			btnEditSelectPat.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					EditPatientFrame Editframe = new EditPatientFrame();
					Editframe.setVisible(true);
					JOptionPane.showMessageDialog(null, "Please press save to save changes!");
				}
			});
			btnEditSelectPat.setBounds(569, 482, 196, 29);
			add(btnEditSelectPat);
			btnEditSelectPat.setToolTipText("Click here to edit patients' information");
			
			
		/**
		 * Delete selected/all buttons 
		 * Displays for both options, a message window asking the user for confirmation 
		 * If yes, it proceeds and if now it cancels the delete action 
		 */
			
			JButton btnDeleteSelectedPatient = new JButton("Delete Selected Patient");
			btnDeleteSelectedPatient.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
			
					int dialogButton = JOptionPane.YES_NO_OPTION;
	                int dialogResult = JOptionPane.showConfirmDialog (null,  "Are you sure you want to delete this patient?","Warning",dialogButton);
	                if(dialogResult == JOptionPane.YES_OPTION){
	                	Database.PatientsList.remove(patientsListGui.getSelectedIndex());
						fill_list(patientsListGui);
	                }
				}
			});
			btnDeleteSelectedPatient.setBounds(569, 511, 196, 29);
			add(btnDeleteSelectedPatient);
			btnDeleteSelectedPatient.setToolTipText("Click here to delete one patient from the list");
			
			JButton btnDeleteAllPatients = new JButton("Delete All Patients");
			btnDeleteAllPatients.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int dialogButton = JOptionPane.YES_NO_OPTION;
	                int dialogResult = JOptionPane.showConfirmDialog (null, "Are you sure you want to delete all the list of patient?","Warning",dialogButton);
	                if(dialogResult == JOptionPane.YES_OPTION){
					Database.PatientsList.remove(patientsListGui);
					fill_list(patientsListGui);
	                }
				}
			});
			btnDeleteAllPatients.setBounds(569, 538, 196, 29);
			add(btnDeleteAllPatients);
			btnDeleteAllPatients.setToolTipText("Click here to delete all patients");
			
		/**
		 * Refresh list button
		 * Clears all jcomponents in the panel 
		 * Loads the updated list of patients 
		 */
			JButton btnRefreshList = new JButton("Refresh List ");
			btnRefreshList.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					fill_list(patientsListGui);
				
					profilePicLabel.setIcon(null);
					fNameField.setText("");
					lNameField.setText("");
					dobField.setText("");
					addressField.setText("");
					emgNbField.setText("");
					medConField.setText("");
					comField.setText("");
					onlineEditorPane.setText("");
					Scan1Label.setIcon(null);
					Scan1Label.setText(null);
					Scan2Label.setIcon(null);
					Scan2Label.setText(null);
					dayfield.setText("");
					hourfield.setText("");
				}
			});
			btnRefreshList.setBounds(569, 597, 196, 29);
			add(btnRefreshList);
			btnRefreshList.setToolTipText("Click here to see ipdated list of patients and their attributes");
			
			JLabel searchForLabel = new JLabel("Search for");
			searchForLabel.setHorizontalAlignment(SwingConstants.CENTER);
			searchForLabel.setBounds(10, 11, 86, 16);
			add(searchForLabel);
			
			searchField = new JTextField();
			searchField.setBounds(20, 43, 130, 26);
			add(searchField);
			searchField.setColumns(10);
			
			JComboBox<String> searchComboBox = new JComboBox<String>();
			searchComboBox.addItem("firstname");
			searchComboBox.addItem("lastname");
			searchComboBox.addItem("address");
			searchComboBox.addItem("date of birth");
			searchComboBox.addItem("emergency number");
			searchComboBox.addItem("medical condition");
			searchComboBox.addItem("comments");
			searchComboBox.addItem("appt day");
			searchComboBox.addItem("appt hour");
			searchComboBox.setBounds(30, 79, 144, 27);
			add(searchComboBox);
		
		/**
		 * Search button
		 * Jlist is first cleared then it displays results of the search, if any 
		 * Uses if statements for each one of the patient's attributes
		 * Further comments below to delimit each search by fields
		 */
			
			JButton btnGo = new JButton("Go");
			btnGo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {

					if (patientsListGui.getItemCount() != 0 )
						patientsListGui.removeAll();
					
					   /*
					    * Search by first name
					    */
					
						if (searchComboBox.getSelectedItem() == "firstname") {
							boolean flag = false;
							for (int i = 0; i <Database.PatientsList.size(); i++) {
							if (Database.PatientsList.get(i).getFirstName().contains(searchField.getText())) {
								flag = true;
								patientsListGui.add(Database.PatientsList.get(i).getLastName() + ", " + 
										Database.PatientsList.get(i).getFirstName()); // + ", " +  Database.PatientsList.get(i).getID());
							} 							
						}
							if (flag == false) {
								patientsListGui.removeAll();
								JOptionPane.showMessageDialog(null, "No results found"); }
					}
						
						/*
						 * Search by last name
						 */
						
						if (searchComboBox.getSelectedItem() == "lastname") {
							boolean flag = false;
							for (int i = 0; i <Database.PatientsList.size(); i++) {
							if (Database.PatientsList.get(i).getLastName().contains(searchField.getText())) {
								flag = true;
								patientsListGui.add(Database.PatientsList.get(i).getLastName() + ", " + 
										Database.PatientsList.get(i).getFirstName()); // + ", " +  Database.PatientsList.get(i).getID());
							} 							
						}
							if (flag == false) {
								patientsListGui.removeAll();
								JOptionPane.showMessageDialog(null, "No results found"); }
					}
						/*
						 * Search by address
						 */
						
						if (searchComboBox.getSelectedItem() == "address") {
							boolean flag = false;
							for (int i = 0; i <Database.PatientsList.size(); i++) {
							if (Database.PatientsList.get(i).getAddress().contains(searchField.getText())) {
								flag = true;
								patientsListGui.add(Database.PatientsList.get(i).getLastName() + ", " + 
										Database.PatientsList.get(i).getFirstName()); // + ", " +  Database.PatientsList.get(i).getID());
							} 							
						}
							if (flag == false) {
								patientsListGui.removeAll();
								JOptionPane.showMessageDialog(null, "No results found"); }
					}
						/*
						 * Search by date of birth
						 */
						
						if (searchComboBox.getSelectedItem() == "date of birth") {
							boolean flag = false;
							for (int i = 0; i <Database.PatientsList.size(); i++) {
							if ((Database.PatientsList.get(i).getDob()).contains(searchField.getText())) {
								flag = true;
								patientsListGui.add(Database.PatientsList.get(i).getLastName() + ", " + 
										Database.PatientsList.get(i).getFirstName()); // + ", " +  Database.PatientsList.get(i).getID());
							} 							
						}
							if (flag == false) {
								patientsListGui.removeAll();
								JOptionPane.showMessageDialog(null, "No results found"); }
					}
						
						/*
						 * Search by emergency number
						 */
						
						if (searchComboBox.getSelectedItem() == "emergency number") {
							boolean flag = false;
							for (int i = 0; i <Database.PatientsList.size(); i++) {
							if (Database.PatientsList.get(i).getEmgNb().contains(searchField.getText())) {
								flag = true;
								patientsListGui.add(Database.PatientsList.get(i).getLastName() + ", " + 
										Database.PatientsList.get(i).getFirstName()); // + ", " +  Database.PatientsList.get(i).getID());
							} 							
						}
							if (flag == false) {
								patientsListGui.removeAll();
								JOptionPane.showMessageDialog(null, "No results found"); }
					}
						
						/*
						 * Search by medical condition
						 */
						
						if (searchComboBox.getSelectedItem() == "medical condition") {
							boolean flag = false;
							for (int i = 0; i <Database.PatientsList.size(); i++) {
							if (Database.PatientsList.get(i).getMedCon().contains(searchField.getText())) {
								flag = true;
								patientsListGui.add(Database.PatientsList.get(i).getLastName() + ", " + 
										Database.PatientsList.get(i).getFirstName()); // + ", " +  Database.PatientsList.get(i).getID());
							} 							
						}
							if (flag == false) {
								patientsListGui.removeAll();
								JOptionPane.showMessageDialog(null, "No results found"); }
					}
						
						/*
						 * Search by comments
						 */
						
						if (searchComboBox.getSelectedItem() == "comments") {
							boolean flag = false;
							for (int i = 0; i <Database.PatientsList.size(); i++) {
							if (Database.PatientsList.get(i).getComment().contains(searchField.getText())) {
								flag = true;
								patientsListGui.add(Database.PatientsList.get(i).getLastName() + ", " + 
										Database.PatientsList.get(i).getFirstName()); // + ", " +  Database.PatientsList.get(i).getID());
							} 							
						}
							if (flag == false) {
								patientsListGui.removeAll();
								JOptionPane.showMessageDialog(null, "No results found"); }
					}
						
						
						/*
						 * Search by appointment day
						 */
						
						if (searchComboBox.getSelectedItem() == "appt day") {
							boolean flag = false;
							for (int i = 0; i <Database.PatientsList.size(); i++) {
							if (Database.PatientsList.get(i).getApptDay().contains(searchField.getText())) {
								flag = true;
								patientsListGui.add(Database.PatientsList.get(i).getLastName() + ", " + 
										Database.PatientsList.get(i).getFirstName()); // + ", " +  Database.PatientsList.get(i).getID());
							} 							
						}
							if (flag == false) {
								patientsListGui.removeAll();
								JOptionPane.showMessageDialog(null, "No results found"); }
					}
						
						/*
						 * Search by appointment hour
						 */
						
						if (searchComboBox.getSelectedItem() == "appt hour") {
							boolean flag = false;
							for (int i = 0; i <Database.PatientsList.size(); i++) {
							if (Database.PatientsList.get(i).getApptHour().contains(searchField.getText())) {
								flag = true;
								patientsListGui.add(Database.PatientsList.get(i).getLastName() + ", " + 
										Database.PatientsList.get(i).getFirstName()); // + ", " +  Database.PatientsList.get(i).getID());
							} 							
						}
							if (flag == false) {
								patientsListGui.removeAll();
								JOptionPane.showMessageDialog(null, "No results found"); }
					}
						
				}
			});
			btnGo.setBounds(147, 43, 41, 29);
			add(btnGo);
			btnGo.setToolTipText("Click here to search for patients by attribute, the results are displayed in the list below");
			
			/**
			 * Import button
			 * Calls the load database method in the database class 
			 * Allows the user to load data to the list of patients (see comments on load method in database class for more details)
			 */
			
			JButton btnImport = new JButton("Import");
			btnImport.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Database.loadDatabase();
				}
			});
			btnImport.setBounds(20, 549, 117, 29);
			add(btnImport);
			btnImport.setToolTipText("Click here to import data about patients from a file");
			
			/**
			 * Export button
			 * Calls the save database method in the database class 
			 * Allows the user to save the data of patients in a file (see comments on save method in database class for more details)
			 */
			
			JButton btnExport = new JButton("Export");
			btnExport.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Database.saveDatabase();
				}
			});
			btnExport.setBounds(20, 583, 117, 29);
			add(btnExport);
			btnExport.setToolTipText("Click here to export the list of patients and their attributes to a file");
			
			/**
			 * Help button 
			 * Displays a message window asking the user to hover with their mouse to know what each jcomponent is used for
			 */
			
			JButton btnHelp = new JButton("HELP");
			btnHelp.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Start by adding patients, they will be then displayed in the list in the left hand side \n  "
							+ "Click on each patient's name to see their attributes displayed \n "
							+ "Hover with your mouse over buttons and boxes to see how to use them");
				}
			});
			btnHelp.setBounds(609, 567, 117, 29);
			add(btnHelp);
			
			
		/**
		 * Mouse listener implemented for list displayed on the patient panel 
		 * When the user clicks on one patient, its attributes are directly displayed in the corresponding fields 
		 * More comments are provided below for jcomponent needing explanation 
		 */
			
			patientsListGui.addMouseListener(new MouseAdapter() {

				@Override
				public void mouseClicked(MouseEvent arg0) {
					System.err.println(patientsListGui.getSelectedItem().toString());
					
					/*
					 * Display profile picture 
					 * A buffered image is appended to the profile label after it is resized to fit the jlabel's dimensions 
					 */
					
					ImageIcon icon_profile = null;
					String path_profile = Database.PatientsList.get(patientsListGui.getSelectedIndex()).getProfilePic().toString();
					if (path_profile != null) {
						try {
							
							Image image_profile = ImageIO.read(new File(path_profile));
							BufferedImage sized_image = new BufferedImage(profilePicLabel.getWidth(),profilePicLabel.getHeight(),BufferedImage.TYPE_INT_RGB);
							Graphics g_profile = sized_image.createGraphics();
							g_profile.drawImage(image_profile, 0, 0, profilePicLabel.getWidth(), profilePicLabel.getHeight(),null);
							g_profile.dispose();
							icon_profile = new ImageIcon(sized_image);
						} catch (IOException e) {
							e.printStackTrace();
						} 
						profilePicLabel.setIcon(icon_profile);
					} else if (path_profile == null) {
						profilePicLabel.setText("No Profile Picture");
					}
					
					/*
					 * Display rest of jtextfields  
					 */
					
					fNameField.setText(Database.PatientsList.get(patientsListGui.getSelectedIndex()).getFirstName());
					lNameField.setText(Database.PatientsList.get(patientsListGui.getSelectedIndex()).getLastName());				
					dobField.setText(Database.PatientsList.get(patientsListGui.getSelectedIndex()).getDob());
					addressField.setText(Database.PatientsList.get(patientsListGui.getSelectedIndex()).getAddress());
					emgNbField.setText(Database.PatientsList.get(patientsListGui.getSelectedIndex()).getEmgNb());
					medConField.setText(Database.PatientsList.get(patientsListGui.getSelectedIndex()).getOnlineDoc());
					
					/*
					 * Display online link in jeditorpane
					 */
					
					if (Database.PatientsList.get(patientsListGui.getSelectedIndex()).getOnlineDoc().isEmpty()) {
						onlineEditorPane.setText("No link available");
					} else {
					
					String savedLink = Database.PatientsList.get(patientsListGui.getSelectedIndex()).getMedCon();
					onlineEditorPane.setEditorKit(JEditorPane.createEditorKitForContentType("text/html"));
					onlineEditorPane.setEditable(false);
					StringBuilder sb = new StringBuilder();
					sb.append("<a href=\"");
					sb.append(savedLink);
					sb.append("\">See Online Description</a>");
					onlineEditorPane.setText(sb.toString());
					onlineEditorPane.addHyperlinkListener(new HyperlinkListener() {
						public void hyperlinkUpdate(HyperlinkEvent e) {
							if(e.getEventType() == HyperlinkEvent.EventType.ACTIVATED) {
								if(Desktop.isDesktopSupported()) {
								    try {
										Desktop.getDesktop().browse(e.getURL().toURI());
									} catch (IOException | URISyntaxException e1) {
										e1.printStackTrace();
									}
								}
							}
						}
					});
					}
					
					/*
					 * Display scans 
					 * Same method as for teh profile picture
					 */

					Scan1Label.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan1());
					if (Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan1() != null) {
						ImageIcon icon_scan1 = null;
						try {
							Image image_scan1 = ImageIO.read(new File(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan1()));
							BufferedImage sized_image = new BufferedImage(Scan1Label.getWidth(),Scan1Label.getHeight(),BufferedImage.TYPE_INT_RGB);
							Graphics g_scan1 = sized_image.createGraphics();
							g_scan1.drawImage(image_scan1, 0, 0, Scan1Label.getWidth(), Scan1Label.getHeight(),null);
							g_scan1.dispose();
							icon_scan1 = new ImageIcon(sized_image);
						} catch (IOException e) {
							e.printStackTrace();
						} 
						Scan1Label.setIcon(icon_scan1);
					} else if (Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan1() == null) {
						Scan1Label.setText("No Scan Available");
					}
					
					Scan2Label.setText(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan2());
					if (Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan2() != null) {
						ImageIcon icon_scan2 = null;
						try {
							Image image_scan2 = ImageIO.read(new File(Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan2()));
							BufferedImage sized_image = new BufferedImage(Scan2Label.getWidth(),Scan2Label.getHeight(),BufferedImage.TYPE_INT_RGB);
							Graphics g_scan2 = sized_image.createGraphics();
							g_scan2.drawImage(image_scan2, 0, 0, Scan2Label.getWidth(), Scan2Label.getHeight(),null);
							g_scan2.dispose();
							icon_scan2 = new ImageIcon(sized_image);
						} catch (IOException e) {
							e.printStackTrace();
						} 
						Scan2Label.setIcon(icon_scan2);
					} else if (Database.PatientsList.get(PatientPanel.patientsListGui.getSelectedIndex()).getScan2() == null) {
						Scan2Label.setText("");
					}
					
					
					/*
					 * Display rest of jtextfields
					 */
					
					comField.setText(Database.PatientsList.get(patientsListGui.getSelectedIndex()).getComment());
					dayfield.setText(Database.PatientsList.get(patientsListGui.getSelectedIndex()).getApptDay());
					hourfield.setText(Database.PatientsList.get(patientsListGui.getSelectedIndex()).getApptHour());
				}
			});
			

	}
}
