/**
 * @author rim_ahsaini 
 * Allows user to have access to main Patient Panel class 
 */

package loginScreens;

import java.awt.Color;



import java.awt.EventQueue;
import java.awt.Window;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import guiPatient.PatientPanel;

import guiPatient.MainMgt;
import userPack.User;
import userPack.UserDatabase;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.IOException;

public class SignIn extends JFrame {

	public static final long serialVersionUID = 1L;
	public JPanel contentPane;
	public JTextField userTField;
	public JPasswordField passwordField;
	public static User user_1;
	public static User user_2;

	/**
	 * Launch the application.
	 */
	
	public static void main(String[] args) {
		
		user_1 = new User("rim", "java");
		user_2 = new User("yassine", "2016");
		UserDatabase.UsersList.add(user_1);
		UserDatabase.UsersList.add(user_2);
		 
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignIn frame = new SignIn();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


    /**
	 * Create the frame.
	 */
	public SignIn() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		contentPane.setVisible(true);
		
		ImageIcon logo = new ImageIcon("/Users/rimahsaini/Downloads/hospital_ucl.jpg");
		JLabel hospitalLogo = new JLabel(logo);
		hospitalLogo.setBounds(65, 6, 326, 98);
		contentPane.add(hospitalLogo);
		
		JLabel userLabel = new JLabel("Username");
		userLabel.setBounds(65, 125, 81, 16);
		contentPane.add(userLabel);
		
		userTField = new JTextField();
		userTField.setBounds(188, 120, 130, 26);
		contentPane.add(userTField);
		userTField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(188, 148, 130, 26);
		contentPane.add(passwordField);
		
		userTField.requestFocus();
		
		JButton bCancel = new JButton("Cancel");
		bCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//System.exit(0);
				SignIn.this.dispose();
				WelcomeLogin wl = null;
				try {
					wl = new WelcomeLogin();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				wl.setVisible(true);
			}
		});
		bCancel.setBounds(286, 196, 117, 29);
		contentPane.add(bCancel);
		
		String user = userTField.getText();
		char[] pass = passwordField.getPassword();
		String stg_pass = pass.toString();
		//String get = UserDatabase.UsersList.get(i).getUsername();
		
		JButton bEnter = new JButton("Enter");
		bEnter.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					boolean flag = false;

					
					for(User itr: UserDatabase.UsersList) {
						
						if (itr.getUsername().equals(userTField.getText()) && itr.getPassword().equals(String.valueOf(passwordField.getPassword()))) {
							flag = true;
							SignIn.this.dispose();
							MainMgt.setVisible(true);
							JOptionPane.showMessageDialog(null, "Please start by adding your patients using button Add New Patient! \n Press HELP for more information!");
						}  
							
						}
					
					if (flag==false)
						JOptionPane.showMessageDialog(null, "Password and/or Username Incorrect! Please try again");
					
				;
					
		
					}
				
			});
			bEnter.setBounds(172, 196, 117, 29);
			contentPane.add(bEnter);
			
			
			
			JLabel lblPassword = new JLabel("Password");
			lblPassword.setBounds(65, 153, 61, 16);
			contentPane.add(lblPassword);
			
			JButton btnNewButton = new JButton("Back");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					SignIn.this.dispose();
					WelcomeLogin wl = null;
					try {
						wl = new WelcomeLogin();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
					wl.setVisible(true);
				}
			});
			btnNewButton.setBounds(58, 196, 117, 29);
			contentPane.add(btnNewButton);
			
			/**
			 * For touch and feel purposes, press enter key takes user to following field and cursor is already set in first textfield 
			 */
			
        //pressed enter key clicks login button
		KeyAdapter klogin = new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
						bEnter.doClick();
				}
			}
		};
			
        //pressed enter key sets cursor in password field
		KeyAdapter kpass = new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
						passwordField.requestFocus();
				}
			}
		};
		
		    userTField.addKeyListener(kpass);
			passwordField.addKeyListener(klogin);
			
	        //adjust size of components to their content 
			
			setLocationRelativeTo(null);
		
	}
}
