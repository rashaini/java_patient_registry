/**
 * @author rim_ahsaini 
 * Allows user to choose their login details 
 * Data entered in saved in arraylist in Userdatabase class 
 */

package loginScreens;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import patientPack.Database;
import userPack.User;
import userPack.UserDatabase;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class SignUp extends JFrame {

	private JPanel contentPane;
	private User usertoAdd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SignUp frame = new SignUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SignUp() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		contentPane.setVisible(true);
		
		
		ImageIcon logo = new ImageIcon("/Users/rimahsaini/Downloads/hospital_ucl.jpg");
		JLabel hospitalLogo = new JLabel(logo);
		hospitalLogo.setBounds(65, 6, 326, 98);
		contentPane.add(hospitalLogo);
		
		JLabel userLabel = new JLabel("Please choose a username");
		userLabel.setBounds(44, 121, 164, 16);
		contentPane.add(userLabel);
		
		JLabel lblPassword = new JLabel("Please choose a password");
		lblPassword.setBounds(45, 149, 163, 16);
		contentPane.add(lblPassword);
		
		JTextField userTField = new JTextField();
		userTField.setBounds(235, 116, 130, 26);
		contentPane.add(userTField);
		userTField.setColumns(10);
		
		JTextField passwordField = new JPasswordField();
		passwordField.setBounds(235, 148, 130, 26);
		contentPane.add(passwordField);
		
		JButton btnNewButton = new JButton("Save login details");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				
				if (userTField.getText().isEmpty() || passwordField.getText().isEmpty()) {
					
					JOptionPane.showMessageDialog(null, "Please complete both fields!");
				}
				
				else { 
				
				usertoAdd = new User(userTField.getText(), passwordField.getText());
				UserDatabase.UsersList.add(usertoAdd);
				SignUp.this.dispose();
				SignIn si = new SignIn();
				si.setVisible(true);
				}
			}
		});
		btnNewButton.setBounds(211, 212, 154, 29);
		contentPane.add(btnNewButton);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SignUp.this.dispose();
				WelcomeLogin wl = null;
				try {
					wl = new WelcomeLogin();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				wl.setVisible(true);
			}
		});
		btnBack.setBounds(70, 212, 117, 29);
		contentPane.add(btnBack);
		
		
		
	    //cursor set in user text field 
		userTField.requestFocus();
		
		 //pressed enter key sets cursor in password field
		KeyAdapter kpass = new KeyAdapter() {
			public void keyPressed(KeyEvent e) {
				if (e.getKeyCode()==KeyEvent.VK_ENTER) {
						passwordField.requestFocus();
				}
			}
		};
		
		//pressed enter key clicks login button
				KeyAdapter klogin = new KeyAdapter() {
					public void keyPressed(KeyEvent e) {
						if (e.getKeyCode()==KeyEvent.VK_ENTER) {
							btnNewButton.doClick();
						}
					}
				};
				
				userTField.addKeyListener(kpass);
				passwordField.addKeyListener(klogin);
	}

}
