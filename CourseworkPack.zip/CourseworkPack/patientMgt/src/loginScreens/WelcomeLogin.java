/**
 * @author rim_ahsaini 
 * First point of entrance of the user with logo and sign in/up options
 */

package loginScreens;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class WelcomeLogin extends JFrame {

	private JPanel contentPane;
	private JTextField txtIfAlreadyRegistered;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					WelcomeLogin frame = new WelcomeLogin();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public WelcomeLogin() throws IOException {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		contentPane.setBackground(Color.WHITE);
		setContentPane(contentPane);
		contentPane.setVisible(true);
		
		
		ImageIcon logo = new ImageIcon("/Users/rimahsaini/Downloads/hospital_ucl.jpg");
		JLabel hospitalLogo = new JLabel(logo);
		hospitalLogo.setBounds(65, 6, 326, 98);
		contentPane.add(hospitalLogo);
		
		JButton btnSignIn = new JButton("Sign In");
		btnSignIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WelcomeLogin.this.dispose();
				SignIn si = new SignIn();
				si.setVisible(true);
			}
		});
		btnSignIn.setBounds(79, 202, 117, 29);
		contentPane.add(btnSignIn);
		btnSignIn.setBackground(Color.BLUE);
		btnSignIn.setForeground(Color.BLACK);
		
		JButton btnNewButton = new JButton("Sign Up");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WelcomeLogin.this.dispose();
				SignUp su = new SignUp();
				su.setVisible(true);
			}
		});
		btnNewButton.setBounds(243, 202, 117, 29);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Please choose an option");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(127, 163, 177, 16);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Welcome to UCLH Patient Management System! ");
		lblNewLabel_1.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(42, 116, 384, 20);
		contentPane.add(lblNewLabel_1);
		
		
		
		
	}
}
