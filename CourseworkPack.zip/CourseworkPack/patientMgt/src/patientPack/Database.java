/**
 * @author rim_ahsaini
 * Database class contains arraylist that is used to store list of objects of type Patient 
 * Contains two methods used to save arraylist in a file and load data to arraylist from file
 */

package patientPack;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Database {
	
	

	public static ArrayList <Patient> PatientsList = new ArrayList<Patient>();

	/**
	 * This method saves the arraylist used as patients database in a file
	 * The solution uses flat files serialization to save lists of data (patients records)
	 * This approach of data handling simplifies data storage and back up, to preserve the data in a light weight file
	 * @param None
	 * @exception IOException 
	 */
	public static void saveDatabase(){
		try{
	         FileOutputStream fos= new FileOutputStream("patientsDB");
	         ObjectOutputStream oos= new ObjectOutputStream(fos);
	         oos.writeObject(PatientsList);
	         oos.close();
	         fos.close();
	       }catch(IOException ioe){
	            ioe.printStackTrace();
	        }
	}
	
	
	/**
	 * This method reads from a file and loads the file content to the ArrayList of patients 
	 * The solution uses flat files serialization load the lists of data (patients records)
	 * This approach of data handling simplifies data storage and back up, to preserve the data in a light weight file
	 * @param None
	 * @exception IOException 
	 * @exception ClassNotFoundException
	 */
	public static  void loadDatabase(){
		
		try
        {
            FileInputStream fis = new FileInputStream("patientsDB");
            ObjectInputStream ois = new ObjectInputStream(fis);
            PatientsList = (ArrayList) ois.readObject();
            ois.close();
            fis.close();
         }catch(IOException ioe){
             ioe.printStackTrace();
             return;
          }catch(ClassNotFoundException c){
             System.out.println("Class not found");
             c.printStackTrace();
             return;
          }
	} 
	
	
}
