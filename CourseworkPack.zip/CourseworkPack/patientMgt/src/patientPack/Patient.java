/**
 * @author rim_ahsaini
 * Patient class is serializable to allow for I/O streams 
 * Define objects of type patients used to add all patients' attributes
 */

package patientPack;

import java.io.Serializable;

public class Patient implements Serializable {
	private String profilePic;
	private String lastName;
	private String firstName;
	private String dob;
	private String address;
	private String emgNb;
	private String medCon;
	private String comment;
	private String onlineDoc;
	private String scan1;
	private String scan2;
	private String apptDay;
	private String apptHour;
	
	
	/**
	 * Only one constructor  is used, formed of Strings
	 */
	public Patient(String profilePic, String lastName, String firstName, String dob, String address,
			String emgNb, String onlineDoc, String medCon, String comment, String scan1, String scan2, String apptDay, String apptHour) {
		super();
		this.profilePic = profilePic;
		this.lastName = lastName;
		this.firstName = firstName;
		this.dob = dob;
		this.address = address;
		this.emgNb = emgNb;
		this.medCon = medCon;
		this.comment = comment;
		this.onlineDoc = onlineDoc;
		this.scan1 = scan1;
		this.scan2 = scan2;
		this.apptDay = apptDay;
		this.apptHour = apptHour;  
	}
	
	
	/**
	 * Getters and setters for all variables in patient objects 
	 */
	
	public String getProfilePic() {
		return profilePic;
	}
	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmgNb() {
		return emgNb;
	}
	public void setEmgNb(String emgNb) {
		this.emgNb = emgNb;
	}
	public String getMedCon() {
		return medCon;
	}
	public void setMedCon(String medCon) {
		this.medCon = medCon;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getOnlineDoc() {
		return onlineDoc;
	}
	public void setOnlineDoc(String onlineDoc) {
		this.onlineDoc = onlineDoc;
	}
	public String getScan1() {
		return scan1;
	}
	public void setScan1(String scan1) {
		this.scan1 = scan1;
	}
	public String getScan2() {
		return scan2;
	}
	public void setScan2(String scan2) {
		this.scan2 = scan2;
	}
	public String getApptDay() {
		return apptDay;
	}
	public void setApptDay(String apptDay) {
		this.apptDay = apptDay;
	}
	public String getApptHour() {
		return apptHour;
	}
	public void setApptHour(String apptHour) {
		this.apptHour = apptHour;
	}
}