/**
 * @author rim_ahsaini 
 * Contains arraylist to store username and password of users after they sign up for the first time 
 */

package userPack;

import java.util.ArrayList;

public class UserDatabase {
	
	public static ArrayList <User> UsersList = new ArrayList<User>();

}
